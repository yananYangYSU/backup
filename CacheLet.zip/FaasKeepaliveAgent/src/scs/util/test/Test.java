package scs.util.test;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<People> list=new ArrayList<People>();
		list.add(new People("a"));
		list.add(new People("b"));
		list.add(new People("c"));
		ArrayList<People> tempList=new ArrayList<People>();
		tempList.addAll(list);
		for(People item:list){
			list.remove(item);
			
		}
		System.out.println(list);
		System.out.println(tempList);
	}

}
