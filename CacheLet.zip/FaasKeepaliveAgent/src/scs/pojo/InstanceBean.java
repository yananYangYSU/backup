package scs.pojo;

import java.io.Serializable;

public class InstanceBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String funcName;
	private long createTime;
	private long lastActiveTimeStart;
	private long lastActiveTimeEnd;
	private float clock;
	
	public InstanceBean(String funcName, long createTime, long lastActiveTimeStart, long lastActiveTimeEnd, float clock) {
		super();
		this.funcName = funcName;
		this.createTime = createTime;
		this.lastActiveTimeStart = lastActiveTimeStart;
		this.lastActiveTimeEnd = lastActiveTimeEnd;
		this.clock = clock;
	}
	
	public String getFuncName() {
		return funcName;
	}
	public long getCreateTime() {
		return createTime;
	}
	public long getLastActiveTimeStart() {
		return lastActiveTimeStart;
	}
	public long getLastActiveTimeEnd() {
		return lastActiveTimeEnd;
	}
	public float getClock() {
		return clock;
	}
	public void setFuncName(String funcName) {
		this.funcName = funcName;
	}
	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}
	public void setLastActiveTimeStart(long lastActiveTimeStart) {
		this.lastActiveTimeStart = lastActiveTimeStart;
	}
	public void setLastActiveTimeEnd(long lastActiveTimeEnd) {
		this.lastActiveTimeEnd = lastActiveTimeEnd;
	}
	public void setClock(float clock) {
		this.clock = clock;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("InstanceBean [funcName=");
		builder.append(funcName);
		builder.append(", createTime=");
		builder.append(createTime);
		builder.append(", lastActiveTimeStart=");
		builder.append(lastActiveTimeStart);
		builder.append(", lastActiveTimeEnd=");
		builder.append(lastActiveTimeEnd);
		builder.append(", clock=");
		builder.append(clock);
		builder.append("]");
		return builder.toString();
	}
	
	 
	
}
