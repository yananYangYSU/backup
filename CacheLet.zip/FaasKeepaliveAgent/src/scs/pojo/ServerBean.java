package scs.pojo;

import java.util.Map;

public class ServerBean {
	private String agentName;
	private int memorySize;
	private int availMemorySize;
	private float logicalClock;
	private Map<String, FuncInstBean> funcInstMap; //<key, value> = <funcName, funcInstBean>

	public ServerBean(String agentName, int memorySize, int availMemorySize,
			Map<String, FuncInstBean> funcInstMap, float logicalClock) {
		super();
		this.agentName = agentName;
		this.memorySize = memorySize;
		this.availMemorySize = availMemorySize;
		this.funcInstMap = funcInstMap; 
		this.logicalClock = logicalClock;
	}

	public String getAgentName() {
		return agentName;
	}
	public int getMemorySize() {
		return memorySize;
	}
	public int getAvailMemorySize() {
		return availMemorySize;
	}
	public Map<String, FuncInstBean> getFuncInstMap() {
		return funcInstMap;
	}
	public float getLogicalClock() {
		return logicalClock;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public void setMemorySize(int memorySize) {
		this.memorySize = memorySize;
	}
	public void setAvailMemorySize(int availMemorySize) {
		this.availMemorySize = availMemorySize;
	}
	public void setLogicalClock(float logicalClock) {
		this.logicalClock = logicalClock;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AgentBean [agentName=");
		builder.append(agentName);
		builder.append(", memorySize=");
		builder.append(memorySize);
		builder.append(", availMemorySize=");
		builder.append(availMemorySize);
		builder.append(", funcInstMap=");
		builder.append(funcInstMap); 
		builder.append(", logicalClock=");
		builder.append(logicalClock);
		builder.append("]");
		return builder.toString();
	}


}
