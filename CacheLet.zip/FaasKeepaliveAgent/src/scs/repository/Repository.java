package scs.repository;

import java.io.IOException; 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map; 
import java.util.Set;


import scs.pojo.FuncInstBean;
import scs.pojo.FuncMetadataBean;
import scs.pojo.InstanceBean;
import scs.pojo.RequestBean;
import scs.pojo.ServerBean;
import scs.pojo.StatisticsBean;
import scs.pojo.TwoTuple;
import scs.util.rmi.RmiService;
import scs.util.tool.FileOperation;

public class Repository {

	private static ServerBean serverBean;

	private static Map<String, FuncMetadataBean> funcMetadataMap=new HashMap<String, FuncMetadataBean>();
	private static int receivedRequestCount=0;
	private static int receivedColdstartCount=0;
	private static int receivedWarmstartCount=0;
	private static int receivedDropCount=0;
	//private static int receivedEvictionCount=0; // useless
	private static int receivedReleaseCount=0;
	private static int receivedInstanceCount=0;
	private static int redirectedCount=0;

	private final static int KEEP_ALIVE_TIME_MS=60*15*1000;
	private final static int STATUS_UPDATE_INTERVAL_TIME_MS=15*1000;
	private static long lastUpdateTime=0;

	private static long lastArrivalTime=0;

	//private final static String outputFilePath="D:\\cacheResearch\\output\\";  //window
	private final static String outputFilePath="/home/tank/1_yanan/cacheResearch/output/";  //linux

	public static void init(String agentName, int memorySize, String ip, int port){
		serverBean=new ServerBean(agentName, memorySize, memorySize, new HashMap<String, FuncInstBean>(), 0);
		System.out.println("Repository.java: init "+serverBean.toString());
		System.out.println("Repository.java: init outputFilePath"+outputFilePath);
		System.out.println("Repository.java: init KEEP_ALIVE_TIME_MS"+KEEP_ALIVE_TIME_MS+"ms, STATUS_UPDATE_INTERVAL_TIME_MS"+"ms");
		RmiService.getInstance().service(ip, port);//start the RMI service
	}

	public static int receiveRequest(RequestBean request){
		receivedRequestCount++;
		lastArrivalTime=request.getArrivalTime();

		//System.out.println("repository.reciveRequest(): "+requestBean.toString());
		FuncMetadataBean funcMetadataBean=request.getFuncMetadata();
		registerFunc(funcMetadataBean);
		checkReleaseInstance(request.getArrivalTime());

		int latency=execRequest(request.getFuncMetadata(), request.getArrivalTime());
		return latency;
	}
	private static void registerFunc(FuncMetadataBean metadataBean){
		if(!funcMetadataMap.containsKey(metadataBean.getFuncName())){
			funcMetadataMap.put(metadataBean.getFuncName(), metadataBean);
			//System.out.println("repository.registerFunc(): register function "+metadataBean.getFuncName());
		}
	}
	private static int execRequest(FuncMetadataBean metadataBean, Long arrivalTime){
		int latency=0;
		if(serverBean.getFuncInstMap().containsKey(metadataBean.getFuncName())){ // function exists
			if(!checkAvailInstance(metadataBean, arrivalTime)){
				//System.out.println("repository.execRequest(): no available instance for function "+metadataBean.getFuncName()+", request arrival time="+arrivalTime);
				if(createInstance(metadataBean, arrivalTime)){
					if(checkAvailInstance(metadataBean, arrivalTime)){
						latency=metadataBean.getExecutionTime()+metadataBean.getStartUpTime();
						receivedColdstartCount++;
						serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addColdStartCount();
						//System.out.println("repository.execRequest(): cold start for function "+metadataBean.getFuncName());
					}else{
						latency=99999;
						receivedDropCount++;
						serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addDropCount();
						//System.out.println("repository.execRequest(): check cache failed, node "+serverBean.getAgentName()+" for function "+metadataBean.getFuncName());
					}
				}else{
					latency=99999;
					receivedDropCount++;
					serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addDropCount();
					//System.out.println("repository.execRequest(): update cache failed, request drop for function "+metadataBean.toString()+" arrival time"+arrivalTime);
				}
			}else{
				latency=metadataBean.getExecutionTime();
				receivedWarmstartCount++;
				serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addWarmStartCount();
				//System.out.println("repository.execRequest(): warm start for function "+metadataBean.getFuncName());
			}
		}else{ 
			serverBean.getFuncInstMap().put(metadataBean.getFuncName(), new FuncInstBean(new ArrayList<InstanceBean>(), 0, null)); // init one function
			//System.out.println("repository.execRequest(): not available instance for function"+metadataBean.getFuncName()+", request arrval time="+arrivalTime);
			if(createInstance(metadataBean, arrivalTime)){
				if(checkAvailInstance(metadataBean, arrivalTime)){
					latency=metadataBean.getExecutionTime()+metadataBean.getStartUpTime();
					receivedColdstartCount++;
					serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addColdStartCount();
					//System.out.println("repository.execRequest(): cold start for function "+metadataBean.getFuncName());
				}else{
					latency=99999;
					receivedDropCount++;
					serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addDropCount();
					//System.out.println("repository.execRequest(): check cache failed 2, node "+serverBean.getAgentName()+" for function "+metadataBean.getFuncName());
				}
			}else{
				latency=99999;
				receivedDropCount++;
				serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addDropCount();
				//System.out.println("repository.execRequest(): update cache failed 2, request drop for function "+metadataBean.toString()+" arrival time"+arrivalTime);
			}
		}

		// update frequency
		serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addReceivedReqCount(); // update frequency of function
		//System.out.println("repository.execRequest(): update frequecy for function "+metadataBean.toString()+" before="+(serverBean.getFuncInstMap().get(metadataBean.getFuncName()).getFrequecy()-1)+" after="+(serverBean.getFuncInstMap().get(metadataBean.getFuncName()).getFrequecy()));

		return latency;
	}

	private static boolean checkAvailInstance(FuncMetadataBean functionBean, long arrivalTime){
		boolean isExist=false;
		ArrayList<InstanceBean> instanceList=serverBean.getFuncInstMap().get(functionBean.getFuncName()).getInstanceList();
		for(InstanceBean instanceItem: instanceList){
			if(instanceItem.getLastActiveTimeEnd()<=arrivalTime){ // 由于有keepalive超时检测函数的存在，这里不需要判断是否超时
				instanceItem.setLastActiveTimeStart(arrivalTime);
				instanceItem.setLastActiveTimeEnd(arrivalTime+functionBean.getExecutionTime());
				isExist=true;
				break;
			}
		}
		return isExist;
	}

	private static void checkReleaseInstance(long arrivalTime){
		if(arrivalTime-lastUpdateTime>STATUS_UPDATE_INTERVAL_TIME_MS){
			////System.out.println("Repository.updateStatus(): checking.... current time= "+currentTime/1000+"s");
			Set<String> keySet=serverBean.getFuncInstMap().keySet();
			InstanceBean temp=null;
			for(String funcName:keySet){
				ArrayList<InstanceBean> instanceList=serverBean.getFuncInstMap().get(funcName).getInstanceList();
				if(instanceList.size()>0){
					////System.out.println(funcName+" "+instanceList.size()+" "+serverBean.getAvailMemorySize());
					for(Iterator<InstanceBean> item=instanceList.iterator();item.hasNext();){
						temp=item.next();
						////System.out.println(item.toString());
						if((temp.getLastActiveTimeEnd()>0)&&(arrivalTime-temp.getLastActiveTimeEnd()>KEEP_ALIVE_TIME_MS)){
							//System.out.println("repository.updateStatus(): release instance"+item.toString()+" before memory="+serverBean.getAvailMemorySize()+" after that memory="+(serverBean.getAvailMemorySize()+funcMetadataMap.get(item.getFuncName()).getMemoryConsume()));
							serverBean.setAvailMemorySize(serverBean.getAvailMemorySize()+funcMetadataMap.get(temp.getFuncName()).getMemoryConsume());
							item.remove();

							{
								float memoryTimeCost=(lastArrivalTime-temp.getCreateTime())/1000.0f*funcMetadataMap.get(temp.getFuncName()).getMemoryConsume();
								serverBean.getFuncInstMap().get(temp.getFuncName()).addMemoryTimespanCost(memoryTimeCost);
								serverBean.getFuncInstMap().get(temp.getFuncName()).addReleaseCount();
							}
							receivedReleaseCount++;
						}else{
							////System.out.println("skip"+item.getLastActiveTimeEnd()+" "+currentTime+" "+(currentTime-item.getLastActiveTimeEnd()));
						}
					}
				}
			}
			lastUpdateTime=arrivalTime;
		}
	}
	private static boolean createInstance(FuncMetadataBean newFuncMetadataBean, long arrivalTime){
		boolean updateFlag=false;
		if(serverBean.getAvailMemorySize()>=newFuncMetadataBean.getMemoryConsume()){
			InstanceBean instanceBean=new InstanceBean(newFuncMetadataBean.getFuncName(), arrivalTime, 0L, 0L, 0);
			serverBean.getFuncInstMap().get(instanceBean.getFuncName()).getInstanceList().add(instanceBean);
			serverBean.setAvailMemorySize(serverBean.getAvailMemorySize()-newFuncMetadataBean.getMemoryConsume());
			//System.out.println("repository.createInstance(): add new instance "+instanceBean.toString()+" before memory="+(serverBean.getAvailMemorySize()+newFuncMetadataBean.getMemoryConsume())+" after that memory="+serverBean.getAvailMemorySize());

			updateFlag=true;
		}
		return updateFlag;
	}

	/**
	 * 计算节点上的工作负载大小
	 * @param arrivalTime
	 * @return TwoTuple<Integer,Float>(); <正在运行实例的内存消耗,CPU负载>
	 */
	public static TwoTuple<Integer, Float> calServerLoad(long arrivalTime){
		int memoryUsage=0;
		Set<String> keySet=serverBean.getFuncInstMap().keySet();
		for(String funcName:keySet){
			ArrayList<InstanceBean> instanceList=serverBean.getFuncInstMap().get(funcName).getInstanceList();
			for(InstanceBean item:instanceList){
				if((item.getLastActiveTimeStart()<=arrivalTime)&&(arrivalTime<=item.getLastActiveTimeEnd())){ 
					memoryUsage+=funcMetadataMap.get(item.getFuncName()).getMemoryConsume();
				}
			}
		}
		float load=memoryUsage/serverBean.getMemorySize();
		return new TwoTuple<Integer,Float>(memoryUsage,load);
	}


	/**
	 * rehash check cache
	 * @param funcName
	 * @param arrivalTime
	 * @return
	 */
	public static boolean probe(RequestBean request){
		boolean redirectFlag=true;

		String funcName=request.getFuncMetadata().getFuncName();
		long arrivalTime=request.getArrivalTime();
		int funcMemory=request.getFuncMetadata().getMemoryConsume();

		/**
		 * 先检查cache是否命中
		 */
		boolean cacheHit=false;
		if(serverBean.getFuncInstMap().containsKey(funcName)){
			ArrayList<InstanceBean> instanceList=serverBean.getFuncInstMap().get(funcName).getInstanceList();
			for(InstanceBean instanceItem: instanceList){
				if(instanceItem.getLastActiveTimeEnd()<=arrivalTime){
					if((instanceItem.getLastActiveTimeEnd()==0)||(arrivalTime-instanceItem.getLastActiveTimeEnd()<KEEP_ALIVE_TIME_MS)){
						cacheHit=true;
						break;
					}
				}
			}
		}
		/**
		 * cache miss 检查是否能创建实例
		 */
		if(cacheHit==false){
			/**
			 * 不会执行具体的删除和实例修改操作
			 */ 
			int serverAvailMemorySize=serverBean.getAvailMemorySize();

			for(Map.Entry<String, FuncInstBean> funcItem: serverBean.getFuncInstMap().entrySet()){
				ArrayList<InstanceBean> instanceList=funcItem.getValue().getInstanceList();
				for(InstanceBean instanceItem:instanceList){
					//刚创建的实例不计入，不空闲或者空闲时间不到释放timeout的实例不计入
					if((instanceItem.getLastActiveTimeEnd()>0)&&(arrivalTime-instanceItem.getLastActiveTimeEnd()>KEEP_ALIVE_TIME_MS)){
						serverAvailMemorySize=serverAvailMemorySize+funcMetadataMap.get(instanceItem.getFuncName()).getMemoryConsume();
					}
				}
			}

			if(serverAvailMemorySize>=funcMemory){
				redirectFlag=false; //cache miss but availMemory
			}
		}else{
			redirectFlag=false; //cache hit
		}

		if(redirectFlag==true){
			redirectedCount++;
			if(!serverBean.getFuncInstMap().containsKey(funcName)){
				serverBean.getFuncInstMap().put(funcName, new FuncInstBean(new ArrayList<InstanceBean>(), 0, null));
			}
			serverBean.getFuncInstMap().get(funcName).addRedirectedCount();
		}

		return redirectFlag;
	}


	//private static float UsedMemoryTime=0;
	//private static float NeverUsedMemoryTime=0;
	public static StatisticsBean display(){ 
		/**
		 * function level的统计
		 */
		StringBuilder result=new StringBuilder();
		result.append("funcName,funcReceivedReqCount,funcWarmCount,funcColdCount,funcDropCount,funcEvictionCount,funcEvictionCount,funcReleaseCount,memoryTimeCost(eviction),totalMemoryCost,uselessRate\n");
		Set<String> keySet=serverBean.getFuncInstMap().keySet();
		for(String funcName:keySet){
			result.append(funcName).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getReceivedReqCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getWarmStartCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getColdStartCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getDropCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getEvictionCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getReleaseCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getRedirectedCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getMemoryTimespanCost()).append(","); //被驱逐实例的memoryTimeCost
			float temp=serverBean.getFuncInstMap().get(funcName).getMemoryTimespanCost();
			for(InstanceBean item: serverBean.getFuncInstMap().get(funcName).getInstanceList()){
				float memoryTimeCost=(lastArrivalTime-item.getCreateTime())/1000.0f*funcMetadataMap.get(item.getFuncName()).getMemoryConsume();
				serverBean.getFuncInstMap().get(funcName).addMemoryTimespanCost(memoryTimeCost);
			}
			result.append(serverBean.getFuncInstMap().get(funcName).getMemoryTimespanCost()).append(","); //驱逐+未被驱逐实例的memoryTimeCost
			result.append(temp/serverBean.getFuncInstMap().get(funcName).getMemoryTimespanCost()*100).append("%");// 那些被被驱逐的实例的内存开销比例
			result.append("\n");
		}  
		try {
			FileOperation.outputFile(result.toString(),outputFilePath+serverBean.getAgentName()+"_func_level_.csv");
		} catch (IOException e) {
			e.printStackTrace();
		}


		/**
		 * server-level的统计
		 */
		receivedInstanceCount=0;
		keySet=serverBean.getFuncInstMap().keySet();
		for(String funcName:keySet){
			if(serverBean.getFuncInstMap().get(funcName).getInstanceList()==null){
			}else{
				receivedInstanceCount+=serverBean.getFuncInstMap().get(funcName).getInstanceList().size();
			}
		} 

		StatisticsBean statisBean=new StatisticsBean();
		statisBean.setAgentName(serverBean.getAgentName());
		statisBean.setMemorySize(serverBean.getMemorySize());
		statisBean.setAvailMemorySize(serverBean.getAvailMemorySize());
		statisBean.setDeployedFunCount(serverBean.getFuncInstMap().size());
		statisBean.setDeployedInstanceCount(receivedInstanceCount);
		statisBean.setTotalRequestCount(receivedRequestCount);
		statisBean.setTotalColdstartCount(receivedColdstartCount);
		statisBean.setTotalWarmstartCount(receivedWarmstartCount);
		statisBean.setTotalReleaseCount(receivedReleaseCount);
		statisBean.setTotalRedirectedCount(redirectedCount);
		statisBean.setTotalDropCount(receivedDropCount);

		statisBean.setFuncLevelStatistics(serverBean.getFuncInstMap());
		//System.out.println(statisBean.getFuncLevelStatistics().toString());
		//System.out.println("NeverUsedMemoryTime="+NeverUsedMemoryTime+"MB*s, Used="+UsedMemoryTime+"MB*s, rate="+(NeverUsedMemoryTime+UsedMemoryTime)/UsedMemoryTime*100+"%");

		return statisBean;
	}
}

