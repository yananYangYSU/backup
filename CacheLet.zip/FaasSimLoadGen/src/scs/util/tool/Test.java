package scs.util.tool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.omg.CORBA.SystemException;

public class Test extends SimpleFileVisitor<Path> {
    private Set<String> pathStringSet = new HashSet<>();

    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
        pathStringSet.add(file.toString());
        return FileVisitResult.CONTINUE;
    }

    public Set<String> getPathStringSet() {
        return pathStringSet;
    }


public static void main(String[] args) throws IOException {
    Path path = Paths.get("C:\\Users\\DELL\\Downloads\\openbilibilicode-master\\");
    Test mfv = new Test();
    Files.walkFileTree(path, mfv);
    Set<String> files=mfv.getPathStringSet();
    for(String file:files){
    	
    	if(file.contains(".go")){
    		mfv.readStringFile(file);
    	}
    }
    
}
public List<String> readStringFile(String filePath) throws IOException {  
	List<String> timeList=new ArrayList<String>();

	File file = new File(filePath); 
	BufferedReader reader = null;
	try {
		FileInputStream fileInputStream = new FileInputStream(file);
		InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
		reader = new BufferedReader(inputStreamReader);
		String line = ""; 

		while ((line = reader.readLine()) != null) { 
			timeList.add(line);
			if(line.contains("riskContent")){
				System.out.println(file);
				System.out.println(line);
				break;
			}
		}

		if (reader != null) {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} finally {
		if (reader != null) {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	return timeList;
}
}