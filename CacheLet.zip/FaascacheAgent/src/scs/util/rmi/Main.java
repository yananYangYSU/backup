package scs.util.rmi;
 
import scs.repository.Repository;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		if(args.length!=4){
			System.out.println("args length="+ args.length);
			System.out.println("[agentName, memorySize(int), ip port]"); 
			System.exit(0);
		}else{
			Repository.init(args[0], Integer.parseInt(args[1]), args[2], Integer.parseInt(args[3]));
		}
		//Repository.init("localhost1",5015, "localhost", 22229); 
	}
 
}
