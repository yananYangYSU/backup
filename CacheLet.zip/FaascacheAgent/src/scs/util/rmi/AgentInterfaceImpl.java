package scs.util.rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import scs.pojo.RequestBean;
import scs.pojo.StatisticsBean;
import scs.pojo.TwoTuple;
import scs.repository.Repository; 

public class AgentInterfaceImpl extends UnicastRemoteObject implements AgentInterface {

	private static final long serialVersionUID = 1L;

	public AgentInterfaceImpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int receiveRequest(RequestBean request,String pattern) throws RemoteException {
		
		//request.setArrivalTime(System.currentTimeMillis()); 
		return Repository.receiveRequest(request);
	}

	@Override
	public StatisticsBean display(int agentIndex) throws RemoteException {
		// TODO Auto-generated method stub
		return Repository.display();
	}

	@Override
	public boolean probe(RequestBean request) {
		// TODO Auto-generated method stub
		return Repository.probe(request);
	}

	@Override
	public void redirectRequest(RequestBean request, String sourceAgent) throws RemoteException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public TwoTuple<Integer, Float> calServerLoad(long arrivalTime) throws RemoteException {
		// TODO Auto-generated method stub
		return Repository.calServerLoad(arrivalTime);
	}

}


