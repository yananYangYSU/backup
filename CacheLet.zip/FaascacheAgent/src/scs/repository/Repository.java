package scs.repository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map; 
import java.util.Set;

import scs.pojo.FuncInstBean;
import scs.pojo.FuncMetadataBean;
import scs.pojo.InstanceBean;
import scs.pojo.RequestBean;
import scs.pojo.ServerBean;
import scs.pojo.StatisticsBean;
import scs.pojo.TwoTuple;
import scs.util.rmi.RmiService;
import scs.util.tool.FileOperation;

public class Repository {

	private static ServerBean serverBean;

	//private final static String outputFilePath="D:\\cacheResearch\\output\\";  //window
	private final static String outputFilePath="/home/tank/1_yanan/cacheResearch/output/";  //linux
			
	private static Map<String, FuncMetadataBean> funcMetadataMap=new HashMap<String, FuncMetadataBean>();
	private static int receivedRequestCount=0;
	private static int redirectedCount=0;
	private static int receivedColdstartCount=0;
	private static int receivedWarmstartCount=0;
	private static int receivedEvictionCount=0;
	private static int receivedDropCount=0;
	private static int receivedInstanceCount=0;
	
	private static long lastArrivalTime=0;

	public static void init(String agentName, int memorySize, String ip, int port){
		serverBean=new ServerBean(agentName, memorySize, memorySize, new HashMap<String, FuncInstBean>(), 0);
		System.out.println("Repository.java: init "+serverBean.toString());
		System.out.println("Repository.java: init outputFilePath"+outputFilePath);
		RmiService.getInstance().service(ip, port);//start the RMI service
	}

	public static int receiveRequest(RequestBean requestBean){
		receivedRequestCount++;
		lastArrivalTime=requestBean.getArrivalTime();
		//System.out.println("repository.reciveRequest(): "+requestBean.toString());
		registerFunc(requestBean.getFuncMetadata());

		int latency=execRequest(requestBean.getFuncMetadata(), requestBean.getArrivalTime());
		return latency;
	}
	private static void registerFunc(FuncMetadataBean metadataBean){
		if(!funcMetadataMap.containsKey(metadataBean.getFuncName())){
			funcMetadataMap.put(metadataBean.getFuncName(), metadataBean);
			//System.out.println("repository.registerFunc(): register function "+metadataBean.getFuncName());
		}
	}
	private static int execRequest(FuncMetadataBean metadataBean, Long arrivalTime){
		int latency=0;
		if(serverBean.getFuncInstMap().containsKey(metadataBean.getFuncName())){ // function exists
			if(!checkCache(metadataBean, arrivalTime)){
				//System.out.println("repository.checkCache(): cache miss for function "+metadataBean.getFuncName()+", request arrival time="+arrivalTime);
				if(updateCache(metadataBean, arrivalTime)){
					if(checkCache(metadataBean, arrivalTime)){
						latency=metadataBean.getExecutionTime()+metadataBean.getStartUpTime();
						receivedColdstartCount++;
						serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addColdStartCount();
						//System.out.println("repository.execRequest(): cold start for function "+metadataBean.getFuncName());
					}else{
						// 系统错误
						latency=99999;
						receivedDropCount++;
						serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addDropCount();
						//System.out.println("repository.execRequest(): check cache failed, node "+serverBean.getAgentName()+" for function "+metadataBean.getFuncName());
					}
				}else{
					// 无可用资源
					latency=99999;
					receivedDropCount++;
					serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addDropCount();
					//System.out.println("repository.execRequest(): update cache failed, request drop for function "+metadataBean.toString()+" arrival time"+arrivalTime);
				}
			}else{
				//System.out.println("repository.checkCache(): cache hit for function"+metadataBean.getFuncName()+", request arrval time="+arrivalTime);
				latency=metadataBean.getExecutionTime();
				receivedWarmstartCount++;
				serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addWarmStartCount();
				//System.out.println("repository.execRequest(): warm start for function "+metadataBean.getFuncName());
			}
		}else{ 
			serverBean.getFuncInstMap().put(metadataBean.getFuncName(), new FuncInstBean(new ArrayList<InstanceBean>(), 0, null)); // init one function
			//System.out.println("repository.checkCache(): cache miss for function"+metadataBean.getFuncName()+", request arrval time="+arrivalTime);
			if(updateCache(metadataBean, arrivalTime)){
				if(checkCache(metadataBean, arrivalTime)){
					latency=metadataBean.getExecutionTime()+metadataBean.getStartUpTime();
					receivedColdstartCount++;
					serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addColdStartCount();
					//System.out.println("repository.execRequest(): cold start for function "+metadataBean.getFuncName());
				}else{
					latency=99999;
					receivedDropCount++;
					serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addDropCount();
					//System.out.println("repository.execRequest(): check cache failed 2, node "+serverBean.getAgentName()+" for function "+metadataBean.getFuncName());
				}
			}else{
				latency=99999;
				receivedDropCount++;
				serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addDropCount();
				//System.out.println("repository.execRequest(): update cache failed 2, request drop for function "+metadataBean.toString()+" arrival time"+arrivalTime);
			}
		}

		// update frequency
		serverBean.getFuncInstMap().get(metadataBean.getFuncName()).addReceivedReqCount(); // update frequency of function
		//System.out.println("repository.execRequest(): update frequecy for function "+metadataBean.toString()+" before="+(serverBean.getFuncInstMap().get(metadataBean.getFuncName()).getFrequecy()-1)+" after="+(serverBean.getFuncInstMap().get(metadataBean.getFuncName()).getFrequecy()));
		return latency;
	}

	private static boolean checkCache(FuncMetadataBean functionBean, long arrivalTime){
		boolean cacheHit=false;
		ArrayList<InstanceBean> instanceList=serverBean.getFuncInstMap().get(functionBean.getFuncName()).getInstanceList();
		for(InstanceBean instanceItem: instanceList){
			if(instanceItem.getLastActiveTimeEnd()<=arrivalTime){
				instanceItem.setLastActiveTimeStart(arrivalTime);
				instanceItem.setLastActiveTimeEnd(arrivalTime+functionBean.getExecutionTime());
				instanceItem.setClock(serverBean.getLogicalClock()); // each time a container is used, update the priority with server clock
				cacheHit=true;
				
				break;
			}
		}
		return cacheHit;
	}
	private static boolean updateCache(FuncMetadataBean newFuncMetadataBean, long arrivalTime){
		/**
		 * 灏藉姏鑰屼负椹遍��
		 */
		float maxPriority=0;
		float tempPriority=0;
		while(serverBean.getAvailMemorySize()<newFuncMetadataBean.getMemoryConsume()){
			tempPriority=localEviction(newFuncMetadataBean.getMemoryConsume(), arrivalTime);
			if(tempPriority==-1){
				break; // local eviction failed
			}
			if(tempPriority>maxPriority){
				maxPriority=tempPriority;
				//System.out.println("repository.updateCache(): update server's clock="+serverBean.getLogicalClock()+" to "+maxPriority);
				serverBean.setLogicalClock(maxPriority); //update server's logical clock on every eviction
				//如果多个实例同时被驱逐，则取其中优先级最大值作为clock
			}
		}

		/**
		 * 灏濊瘯鍒涘缓瀹炰緥
		 */
		boolean updateFlag=false;
		if(serverBean.getAvailMemorySize()>=newFuncMetadataBean.getMemoryConsume()){
			InstanceBean instanceBean=new InstanceBean(newFuncMetadataBean.getFuncName(), arrivalTime, 0L, 0L, 0);
			serverBean.getFuncInstMap().get(instanceBean.getFuncName()).getInstanceList().add(instanceBean);
			serverBean.setAvailMemorySize(serverBean.getAvailMemorySize()-newFuncMetadataBean.getMemoryConsume());
			//System.out.println("repository.updateCache(): add new instance "+instanceBean.toString()+" before memory="+(serverBean.getAvailMemorySize()+newFuncMetadataBean.getMemoryConsume())+" after that memory="+serverBean.getAvailMemorySize());

			updateFlag=true;
		}


		return updateFlag;
	}

	/**
	 * 椹遍�愮畻娉� 低优先级的会被首先驱逐
	 * @param serverBean
	 * @param funcMetadataBean
	 * @return 杩斿洖鐨勬槸姣忔椹遍�愮殑瀹炰緥鐨勪紭鍏堢骇锛堥粯璁ゆ槸鏈�浣庣殑浼樺厛绾э級锛屽鏋滆繑鍥�-1锛屽垯琛ㄧず鏃犲疄渚嬪彲渚涢┍閫�
	 */
	private static float localEviction(int newInstanceMemory, long arrivalTime){
		float minPriority=Integer.MAX_VALUE;
		float currentPriority=0;
		InstanceBean currentInstance=null;
		for(Map.Entry<String, FuncInstBean> funcItem: serverBean.getFuncInstMap().entrySet()){
			ArrayList<InstanceBean> instanceList=funcItem.getValue().getInstanceList();
			for(InstanceBean instanceItem:instanceList){
				if((instanceItem.getLastActiveTimeStart()<=arrivalTime)&&(arrivalTime<=instanceItem.getLastActiveTimeEnd())){
					//System.out.println("repository.localEviction(): eviction of function "+funcItem.getKey()+"'s instance (createTime="+instanceItem.getCreateTime()+" is used) ");
					continue;
				}
				FuncMetadataBean evicFuncMetadata=funcMetadataMap.get(funcItem.getKey());
				currentPriority=instanceItem.getClock()+funcItem.getValue().getReceivedReqCount()*1.0f*evicFuncMetadata.getStartUpTime()/evicFuncMetadata.getMemoryConsume();
				//System.out.println("repository.localEviction(): eviction of function "+funcItem.getKey()+"'s instance (createTime="+instanceItem.getCreateTime()+")'s priority="+tempPriority+" minPriority="+minPriority);
				if(currentPriority<minPriority){
					minPriority=currentPriority;
					currentInstance=instanceItem;
				}
			}
		}
		if(currentInstance!=null){
			//System.out.println("repository.localEviction(): delete instance"+currentInstance.toString()+" before memory="+serverBean.getAvailMemorySize()+" after that memory="+(serverBean.getAvailMemorySize()+funcMetadataMap.get(currentInstance.getFuncName()).getMemoryConsume()));
			serverBean.setAvailMemorySize(serverBean.getAvailMemorySize()+funcMetadataMap.get(currentInstance.getFuncName()).getMemoryConsume());
			serverBean.getFuncInstMap().get(currentInstance.getFuncName()).getInstanceList().remove(currentInstance);

			{
				float memoryTimeCost=(lastArrivalTime-currentInstance.getCreateTime())/1000.0f*funcMetadataMap.get(currentInstance.getFuncName()).getMemoryConsume();

				serverBean.getFuncInstMap().get(currentInstance.getFuncName()).addMemoryTimespanCost(memoryTimeCost);
				serverBean.getFuncInstMap().get(currentInstance.getFuncName()).addEvictionCount();
			}

			receivedEvictionCount++;
		}else{
			minPriority=-1; // there is no instance can be deleted
		}
		return minPriority;
	}

	/**
	 * 计算节点上的工作负载大小
	 * @param arrivalTime
	 * @return TwoTuple<Integer,Float>(); <正在运行实例的内存消耗,CPU负载>
	 */
	public static TwoTuple<Integer, Float> calServerLoad(long arrivalTime){
		int memoryUsage=0;
		Set<String> keySet=serverBean.getFuncInstMap().keySet();
		for(String funcName:keySet){
			ArrayList<InstanceBean> instanceList=serverBean.getFuncInstMap().get(funcName).getInstanceList();
			for(InstanceBean item:instanceList){
				if((item.getLastActiveTimeStart()<=arrivalTime)&&(arrivalTime<=item.getLastActiveTimeEnd())){ 
					memoryUsage+=funcMetadataMap.get(item.getFuncName()).getMemoryConsume();
				}
			}
		}
		float load=memoryUsage/serverBean.getMemorySize();
		return new TwoTuple<Integer,Float>(memoryUsage,load);
	}
	
	public static StatisticsBean display(){ 
		/**
		 * function level的统计
		 */
		StringBuilder result=new StringBuilder();
		result.append("funcName,funcReceivedReqCount,funcWarmCount,funcColdCount,funcDropCount,funcEvictionCount,funcReleaseCount,funcRedirectedCount,memoryTimeCost(evication),totalMemoryCost,uselessRate\n");
		Set<String> keySet=serverBean.getFuncInstMap().keySet();
		for(String funcName:keySet){
			result.append(funcName).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getReceivedReqCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getWarmStartCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getColdStartCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getDropCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getEvictionCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getReleaseCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getRedirectedCount()).append(",");
			result.append(serverBean.getFuncInstMap().get(funcName).getMemoryTimespanCost()).append(","); //被驱逐实例的memoryTimeCost
			float temp=serverBean.getFuncInstMap().get(funcName).getMemoryTimespanCost();
			for(InstanceBean item: serverBean.getFuncInstMap().get(funcName).getInstanceList()){
				float memoryTimeCost=(lastArrivalTime-item.getCreateTime())/1000.0f*funcMetadataMap.get(item.getFuncName()).getMemoryConsume();
				serverBean.getFuncInstMap().get(funcName).addMemoryTimespanCost(memoryTimeCost);
			}
			result.append(serverBean.getFuncInstMap().get(funcName).getMemoryTimespanCost()).append(","); //驱逐+未被驱逐实例的memoryTimeCost
			result.append(temp/serverBean.getFuncInstMap().get(funcName).getMemoryTimespanCost()*100).append("%");// 那些被被驱逐的实例的内存开销比例
			result.append("\n");
		}  
		try {
			FileOperation.outputFile(result.toString(),outputFilePath+serverBean.getAgentName()+"_func_level_.csv");
		} catch (IOException e) {
			e.printStackTrace();
		}


		/**
		 * server-level的统计
		 */
		receivedInstanceCount=0;
		keySet=serverBean.getFuncInstMap().keySet();
		for(String funcName:keySet){
			if(serverBean.getFuncInstMap().get(funcName).getInstanceList()==null){
			}else{
				receivedInstanceCount+=serverBean.getFuncInstMap().get(funcName).getInstanceList().size();
			}
		} 

		StatisticsBean statisBean=new StatisticsBean();
		statisBean.setAgentName(serverBean.getAgentName());
		statisBean.setMemorySize(serverBean.getMemorySize());
		statisBean.setAvailMemorySize(serverBean.getAvailMemorySize());
		statisBean.setDeployedFunCount(serverBean.getFuncInstMap().size());
		statisBean.setDeployedInstanceCount(receivedInstanceCount);
		statisBean.setTotalRequestCount(receivedRequestCount);
		statisBean.setTotalColdstartCount(receivedColdstartCount);
		statisBean.setTotalWarmstartCount(receivedWarmstartCount);
		statisBean.setTotalEvictionCount(receivedEvictionCount);
		statisBean.setTotalRedirectedCount(redirectedCount);
		statisBean.setTotalDropCount(receivedDropCount);

		statisBean.setFuncLevelStatistics(serverBean.getFuncInstMap());
		//System.out.println(statisBean.getFuncLevelStatistics().toString());

		return statisBean;
	}

	/**
	 * rehash check cache
	 * @param funcName
	 * @param arrivalTime
	 * @return
	 */
	public static boolean probe(RequestBean request){
		boolean redirectFlag=true;

		String funcName=request.getFuncMetadata().getFuncName();
		long arrivalTime=request.getArrivalTime();
		int funcMemory=request.getFuncMetadata().getMemoryConsume();

		/**
		 * 先检查cache是否需要命中
		 */
		boolean cacheHit=false;
		if(serverBean.getFuncInstMap().containsKey(funcName)){
			ArrayList<InstanceBean> instanceList=serverBean.getFuncInstMap().get(funcName).getInstanceList();
			for(InstanceBean instanceItem: instanceList){
				if(instanceItem.getLastActiveTimeEnd()<=arrivalTime){
					cacheHit=true;
					break;
				}
			}
		}
		/**
		 * cache miss 检查是否能创建实例
		 */
		if(cacheHit==false){
			/**
			 * 不会执行具体的删除和实例修改操作
			 */ 
			ArrayList<Integer> forbiddenList=new ArrayList<Integer>();
			int serverAvailMemorySize=serverBean.getAvailMemorySize();
			float minPriority=0; //declear
			float currentPriority=0; //declear
			InstanceBean currentInstance; //declear
			while(serverAvailMemorySize<funcMemory){
				{
					minPriority=Integer.MAX_VALUE; //init
					currentPriority=0; //init
					currentInstance=null; //init
					for(Map.Entry<String, FuncInstBean> funcItem: serverBean.getFuncInstMap().entrySet()){
						ArrayList<InstanceBean> instanceList=funcItem.getValue().getInstanceList();
						for(InstanceBean instanceItem:instanceList){
							//已经模拟删除过的不计入
							if(forbiddenList.contains(instanceItem.hashCode())){
								//System.out.println("repository.probe(): instanceItem forbidden hashcode="+instanceItem.hashCode()+" forbiddenList size="+forbiddenList.size());
								continue;
							}
							//正在忙碌的节点不计入
							if((instanceItem.getLastActiveTimeStart()<=arrivalTime)&&(arrivalTime<=instanceItem.getLastActiveTimeEnd())){
								continue;
							}
							FuncMetadataBean evicFuncMetadata=funcMetadataMap.get(funcItem.getKey());
							currentPriority=instanceItem.getClock()+funcItem.getValue().getReceivedReqCount()*1.0f*evicFuncMetadata.getStartUpTime()/evicFuncMetadata.getMemoryConsume();
							if(currentPriority<minPriority){
								//System.out.println("repository.probe(): currentPriority<minPriority ");
								minPriority=currentPriority;
								currentInstance=instanceItem;
							}
						}
					}
					if(currentInstance!=null){
						//System.out.println("repository.probe(): found instance"+currentInstance.toString()+" before memory="+serverAvailMemorySize+" after that memory="+(serverAvailMemorySize+funcMetadataMap.get(currentInstance.getFuncName()).getMemoryConsume()));
						serverAvailMemorySize=serverAvailMemorySize+funcMetadataMap.get(currentInstance.getFuncName()).getMemoryConsume();
						forbiddenList.add(currentInstance.hashCode());
					}else{
						break; // there is no instance can be deleted
					}
				}
			}

			if(serverAvailMemorySize>=funcMemory){
				redirectFlag=false; //cache miss but availMemory
			}
		}else{
			redirectFlag=false; //cache hit
		}

		if(redirectFlag==true){
			redirectedCount++;
			if(!serverBean.getFuncInstMap().containsKey(funcName)){
				serverBean.getFuncInstMap().put(funcName, new FuncInstBean(new ArrayList<InstanceBean>(), 0, null));
			}
			serverBean.getFuncInstMap().get(funcName).addRedirectedCount();
		}

		return redirectFlag;
	}
}

